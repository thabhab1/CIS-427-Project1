https://github.com/thabhab1/CIS-427-Project1.git
-----------

All commands that have been asked for have been implemented, from the Login to the Shutdown and all operations in between.
To build and run my program, simply start the server and then the client (I used Apache Netbeans) the login using LOGIN username password
Commands must be capitalized and there can be no extra spaces such as LOGIN john john22 (one space right after john22) and error handling has been implemented. I have tested all functionality of the program and have not found any bugs.

Client output from my program:

cd C:\Users\Thabet\Documents\NetBeansProjects\CIS427Project1; "JAVA_HOME=C:\\Program Files\\Java\\jdk-17.0.2" cmd /c "\"C:\\Program Files\\NetBeans-12.6\\netbeans\\java\\maven\\bin\\mvn.cmd\" -Dexec.vmArgs= \"-Dexec.args=${exec.vmArgs} -classpath %classpath ${exec.mainClass} ${exec.appArgs}\" \"-Dexec.executable=C:\\Program Files\\Java\\jdk-17.0.2\\bin\\java.exe\" -Dexec.mainClass=Client -Dexec.classpathScope=runtime -Dexec.appArgs= \"-Dmaven.ext.class.path=C:\\Program Files\\NetBeans-12.6\\netbeans\\java\\maven-nblib\\netbeans-eventspy.jar\" -Dfile.encoding=UTF-8 org.codehaus.mojo:exec-maven-plugin:3.0.0:exec"
Running NetBeans Compile On Save execution. Phase execution is skipped and output directories of dependency projects (with Compile on Save turned on) will be used instead of their jar artifacts.
Scanning for projects...

--------------------< com.mycompany:CIS427Project1 >--------------------
Building CIS427Project1 1.0-SNAPSHOT
--------------------------------[ jar ]---------------------------------

--- exec-maven-plugin:3.0.0:exec (default-cli) @ CIS427Project1 ---
Please login, type (LOGIN username password)
LOGIN
Server: 300 Invalid Command. Please input a valid command (LOGIN, SOLVE, LIST, SHUTDOWN, LOGOUT)
L
Server: 300 Invalid Command. Please input a valid command (LOGIN, SOLVE, LIST, SHUTDOWN, LOGOUT)
LOGIN banana
Server: 300 Invalid Command. Please input a valid command (LOGIN, SOLVE, LIST, SHUTDOWN, LOGOUT)
LOGIN root 2
Server: Invalid login.
LOGIN root root22
Server: Logged in as root
LOGIN banana
Server: You are already logged in, please logout to login as another user
SOLVE
Server: Error: No shape found
SOlve
Server: 300 Invalid Command. Please input a valid command (LOGIN, SOLVE, LIST, SHUTDOWN, LOGOUT)
SOLVE -r
Server: Error: No sides found
SOLVE -r 2
Server: Sides 2.0: Rectangle's perimeter is 8.00 and area is 4.00
SOLVE -r 2 3
Server: Sides 2.0 3.0: Rectangle's perimeter is 10.00 and area is 6.00
SOLVE -r 2 3 4
Server: Error: Invalid number(s)
SOLVE -c
Server: Error: Radius not found
SOLVE -c 3
Server: Radius is 3.0: Circle's circumference is 18.85 and area is 28.27
SOLVE -c 3 4
Server: Error: Invalid radius
SOLVE -c -r
Server: Error: Invalid number
SOLVE -c a 
Server: Error: Invalid radius
LIST
Server: 
root
	Radius is 3.0: Circle's circumference is 18.85 and area is 28.27
	Error: No shape found
	Error: No sides found
	Sides 2.0: Rectangle's perimeter is 8.00 and area is 4.00
	Sides 2.0 3.0: Rectangle's perimeter is 10.00 and area is 6.00
	Error: Invalid number(s)
	Error: Radius not found
	Radius is 3.0: Circle's circumference is 18.85 and area is 28.27
	Error: Invalid radius
	Error: Invalid number
	Error: Invalid radius

LIST -alL
Server: Error: Please input a valid command
LIST -all professor do you want to play valheim or phasmophobia with me
Server: Error: Please input a valid command
LIST -all
Server: 
john 
	Sides 3.0: Rectangle's perimeter is 12.00 and area is 9.00
	Sides 3.0 3.0: Rectangle's perimeter is 12.00 and area is 9.00
	Error: Invalid number(s)
	Error: No sides found
	Error: Missing shape and number(s)
	Error: Radius not found
	Radius is 3.0: Circle's circumference is 18.85 and area is 28.27
	Error: Invalid radius
	Error: Missing shape and number(s)
qiang 
	No interactions yet
root 
	Radius is 3.0: Circle's circumference is 18.85 and area is 28.27
	Error: No shape found
	Error: No sides found
	Sides 2.0: Rectangle's perimeter is 8.00 and area is 4.00
	Sides 2.0 3.0: Rectangle's perimeter is 10.00 and area is 6.00
	Error: Invalid number(s)
	Error: Radius not found
	Radius is 3.0: Circle's circumference is 18.85 and area is 28.27
	Error: Invalid radius
	Error: Invalid number
	Error: Invalid radius
sally 
	No interactions yet

LOGOUT
Server: 200 OK
------------------------------------------------------------------------
BUILD SUCCESS
------------------------------------------------------------------------
Total time:  03:12 min
Finished at: 2022-02-07T16:00:29-05:00
------------------------------------------------------------------------


If typing "SHUTDOWN"
SHUTDOWN
Server: 200 OK
------------------------------------------------------------------------
BUILD SUCCESS
------------------------------------------------------------------------
Total time:  3.695 s
Finished at: 2022-02-07T16:04:26-05:00
------------------------------------------------------------------------

