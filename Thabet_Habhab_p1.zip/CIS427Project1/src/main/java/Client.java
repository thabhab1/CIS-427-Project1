
import java.net.*;
import java.io.*;
import java.util.Scanner;

public class Client {    
    public static void main(String[] args) {
        //defining variables and port
        final int SERVER_PORT = 1234;
        Socket clientSocket = null;
        DataInputStream input = null;
        DataOutputStream output = null;
        
        //create the client socket and connection to the server
        try {
            //create new socket for the client to talk to the server
            clientSocket = new Socket("localhost", SERVER_PORT);
            System.out.println("Please login, type (LOGIN username password)");
            //reader and writer and buffers are to handle input/output while being efficient
            input = new DataInputStream(clientSocket.getInputStream());
            output = new DataOutputStream(clientSocket.getOutputStream());
            
            Scanner scan = new Scanner(System.in);
            //take in user input and send to server until logging out
            while(true) {
                String message = scan.nextLine();
                //send user input to the server
                output.writeUTF(message);

                //outputting the input received from server
                System.out.println("Server: " + input.readUTF());                   
                                         
                if(message.equals("LOGOUT") || message.equals("SHUTDOWN")) {
                    break;
                }
            }
            
        }
        catch (Exception err) {
            err.printStackTrace();
        }
        finally {
            //closing all sockets if they are not null, otherwise print stack trace
            try {
                if(clientSocket != null)
                    clientSocket.close();
                if(input != null)
                    input.close();
                if(output != null)
                    output.close();
            }
            catch(Exception err) {
                err.printStackTrace();
            }
        }
        
    }    
    
    
}
