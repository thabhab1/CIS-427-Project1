
import java.net.*;
import java.io.*;
import java.util.Scanner;
import java.util.ArrayList; 

        
public class Server {    
    public static void main(String[] args) {
        //defining and initializing variables and port
        final int SERVER_PORT = 1234;        
        ServerSocket serverSocket = null;
        Socket clientSocket = null;
        DataInputStream input = null;
        DataOutputStream output = null;
        boolean loggedin = false;
        boolean serverFlag = true;
        String[] loginInfo = null;
        String username = null;

        //ensuring that the server is always running even when client dc
        while(serverFlag) {                
            try {
                //initializing variables and socket
                serverSocket = new ServerSocket(SERVER_PORT);
                clientSocket = serverSocket.accept();

                input = new DataInputStream(clientSocket.getInputStream());
                output = new DataOutputStream(clientSocket.getOutputStream());
                
                //keep listening for user input until they logout
                while(true) {
                    
                    String messageFromClient = input.readUTF();
                    
                    System.out.println("Client: " + messageFromClient);
                    //tokenizing user input
                    loginInfo = messageFromClient.split(" ", 4);
                    
                    //if trying to login, see if the username and password combo are valid in login file
                    if(loginInfo[0].equals("LOGIN") && loggedin == false && loginInfo.length == 3) {
                        File loginFile = new File("logins.txt");
                        //cant find file or its empty
                        if(!loginFile.exists() || loginFile.length() == 0) {
                            System.out.println("Login file doesn't exist or is empty.");                            
                        }
                        else {
                            //look for username and password in file 
                            String line = "";
                            Scanner scan = new Scanner(loginFile);
                            //creating solution files for all existing users
                            while(scan.hasNextLine()) {
                                line = scan.nextLine();
                                String[] user = line.split(" ", 2);
                                File createFile = new File("solutions/" + user[0] + "_solutions.txt");
                                createFile.createNewFile();
                            }
                            Scanner scan1 = new Scanner(loginFile);
                            //scanning through the file to find the username and password
                            while(scan1.hasNextLine()) {
                                line = scan1.nextLine();
                                                                
                                if(line.equals(loginInfo[1]+" "+loginInfo[2])) {
                                    loggedin = true;
                                    username = loginInfo[1];
                                    break;
                                }                                   
                            }
                            //successful login
                            if(loggedin == true) {
                                output.writeUTF("Logged in as " + loginInfo[1]);
                            }
                            //invalid login
                            else {
                                output.writeUTF("Invalid login.");
                            }
                        }
                    }
                    //user is already logged in
                    else if(loginInfo[0].equals("LOGIN") && loggedin == true) {
                        output.writeUTF("You are already logged in, please logout to login as another user");
                    }
                    //user wants to solve a problem
                    else if(loginInfo[0].equals("SOLVE") && loggedin == true) {
                        //opening the users solutions file and making sure its there, then writing to it the results of their arguments
                        File usersSolutions = new File("solutions/" + username + "_solutions.txt");
                        usersSolutions.createNewFile();
                        FileWriter fw = new FileWriter(usersSolutions, true);
                        BufferedWriter buffWriter = new BufferedWriter(fw);
                        String result = "";
                        
                        //handling user input and either giving an error or solving accordingly
                        if(loginInfo.length < 2) {
                            result = "Error: No shape found";
                        }
                        else if(loginInfo[1].equals("-c") && loginInfo.length <= 2) {
                            result = "Error: Radius not found";
                        }
                        else if(loginInfo[1].equals("-r") && loginInfo.length <= 2) {
                            result = "Error: No sides found";
                        }                        
                        else if(loginInfo[1].equals("-c")) {
                            //user wants to solve a circle problem
                            try {
                                // if user has more or less than 3 arguments, thats invalid 
                                if(loginInfo.length == 3) {
                                    double num = Double.parseDouble(loginInfo[2]);
                                    result = solve("-c", num);
                                }
                                else {
                                    result = "Error: Invalid radius";
                                }
                                
                            }
                            catch (Exception err) {
                                result = "Error: Invalid number";
                            }
                            
                        }
                        else if(loginInfo[1].equals("-r")) {
                            if(loginInfo.length == 4) {
                                //ensuring user input is numerical and valid
                                try {
                                    double num = Double.parseDouble(loginInfo[2]);
                                    double num2 = Double.parseDouble(loginInfo[3]);
                                    result = solve("-r", num, num2);
                                }
                                catch (Exception err) {
                                    result = "Error: Invalid number(s)";
                                }
                            }
                            else {
                                //ensuring user input is numerical and valid
                                try {
                                    double num = Double.parseDouble(loginInfo[2]);
                                    result = solve("-r", num);
                                }
                                catch (Exception err) {
                                    result = "Error: Invalid number";
                                }
                            }
                        }
                        else {
                            result = "Error: Missing shape and number(s)";
                        }
                        //write the output and close the file to write to disk
                        output.writeUTF(result);
                        buffWriter.write(result);
                        buffWriter.newLine(); 
                        buffWriter.close();
                        fw.close();                        
                        
                    }
                    //user wants to list their solutions                    
                    else if(loginInfo[0].equals("LIST") && loggedin == true) {                    
                        if(loginInfo.length < 2) {
                            File file = new File("solutions/" + username + "_solutions.txt");
                            Scanner solutions = new Scanner(file);
                            //begin outputting all lines in the users file to the user
                            String sol = "\n" + username + "\n";
                            while(solutions.hasNextLine()) {
                                String line = solutions.nextLine();
                                sol = sol.concat("\t" + line + "\n");

                            }
                            //nothing to output, otherwise output the results stored in the users file
                            if(file.length() == 0) {
                                output.writeUTF("\n" + username + "\n" + "\tNo interactions yet");
                            } 
                            else {
                                output.writeUTF(sol);
                            }
                        }
                        else if(loginInfo[1].equals("-all") && !username.equals("root") && loginInfo.length == 2) {
                            output.writeUTF("Error: You are not the root user");
                        }
                        else if(loginInfo[1].equals("-all") && username.equals("root") && loginInfo.length == 2) {
                            //get all the files in the folder and iterate through each
                            //sol string will contain all info from every file and return in the end
                            String sol = "\n";
                            File dir = new File("solutions/");
                            File[] directoryListing = dir.listFiles();
                            if (directoryListing != null) {
                                  
                                for (File child : directoryListing) {
                                    //iterate through each of the files and output their contents
                                    Scanner scan = new Scanner(child);                                        
                                    String userFilesName = child.getName();
                                    userFilesName = userFilesName.replace("_solutions.txt", " ");
                                    sol = sol.concat(userFilesName + "\n");
                                    
                                    //concatenate to sol string the users name and file info
                                    while(scan.hasNextLine()) {
                                        String line = scan.nextLine();
                                        sol = sol.concat("\t" + line + "\n");
                                        
                                    }
                                    //if file is empty there are no results to return
                                    if(child.length() == 0) {
                                        sol = sol.concat("\tNo interactions yet");
                                        sol = sol.concat("\n");
                                    }
                                    
                                }
                            } 
                            output.writeUTF(sol);
                            
                        }                        
                        else {
                            output.writeUTF(("Error: Please input a valid command"));
                        }
                    }
                    //user wants to shutdown the client and the server
                    else if(loginInfo[0].equals("SHUTDOWN") && loginInfo.length == 1) {
                        output.writeUTF("200 OK");
                        serverFlag = false;
                        break;
                    }
                    //user wants to logout of the client
                    else if(loginInfo[0].equals("LOGOUT") && loginInfo.length == 1) {
                        output.writeUTF("200 OK");
                        loggedin = false;
                        break;
                    }
                    //user input an invalid command
                    else {
                        output.writeUTF("300 Invalid Command. Please input a valid command (LOGIN, SOLVE, LIST, SHUTDOWN, LOGOUT)");
                    }
                                        
                } 
                serverSocket.close();
                clientSocket.close();
                input.close();
                output.close();
                
            }
            catch (Exception err) {
                err.printStackTrace();
            }      
            
        }
    }
    //solve methods for when SOLVE is called with appropriate arguments by the user
    public static String solve(String shape, double firstD, double secondD) {
        String result = "";
        //solving the perimeter and area for a rectangle
        if(shape.equalsIgnoreCase("-r")) {
            double perimeter = firstD * 2 + secondD * 2;
            double area = firstD * secondD;
            
            result = "Sides " + firstD + " " + secondD + ": Rectangle's perimeter is " + String.format("%.2f", perimeter) + " and area is " + String.format("%.2f", area);
        }
        return result;
    }
    public static String solve(String shape, double firstD) {
        String result = "";
        //solving the area and circumference for a circle 
        if(shape.equalsIgnoreCase("-c")) {
            double area = Math.PI*(firstD*firstD);
            double circumference = 2*Math.PI*(firstD);
            
            result = "Radius is " + firstD + ": Circle's circumference is " + String.format("%.2f", circumference) + " and area is " + String.format("%.2f", area);
        }
        //solving the perimeter and area for a rectangle
        else if(shape.equalsIgnoreCase("-r")) {
            double perimeter = firstD * 4;
            double area = firstD * firstD;
            
            result = "Sides " + firstD + ": Rectangle's perimeter is " + String.format("%.2f", perimeter) + " and area is " + String.format("%.2f", area);

        }
        return result;
    }    
    
}
